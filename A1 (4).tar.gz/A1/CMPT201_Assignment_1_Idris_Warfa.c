
/*------------------------------------------
Student’s Name: Idris Warfa
Student ID: 3136329
Assignment: #1
Class Section: X02L
Professor: Salwa Abougamila
--------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

/*------------------------------------------
Function: cardinalSort
Description: Reads lines from standard input and
sorts characters in ascending ASCII order using
CardinalSort algorithm.
--------------------------------------------*/
void cardinalSort() {
    char line[1000];
    while (fgets(line, sizeof(line), stdin)) {
        int counts[128] = {0};
        for (int i = 0; line[i] != '\0'; i++) {
            if (line[i] >= 32 && line[i] <= 126) counts[(int)line[i]]++;
        }
        for (int i = 32; i <= 126; i++) {
            for (int j = 0; j < counts[i]; j++) putchar(i);
        }
        putchar('\n');
    }
}

/*------------------------------------------
Function: countingCovid
Description: Counts COVID-19 cases per date from
provided dataset read from standard input.
--------------------------------------------*/
void countingCovid() {
    char line[1000], prevDate[20] = "";
    int count = 0;
    fgets(line, sizeof(line), stdin); // Skip header
    while (fgets(line, sizeof(line), stdin)) {
        char date[20];
        sscanf(line, "%*[^,],%[^,]", date);
        if (strcmp(date, prevDate) == 0) count++;
        else {
            if (count > 0) printf("%s %d\n", prevDate, count);
            strcpy(prevDate, date);
            count = 1;
        }
    }
    if (count > 0) printf("%s %d\n", prevDate, count);
}

/*------------------------------------------
Function: xTable
Description: Prints a table for expression:
x^4 / y^4 + sqrt(y) for x and y in multiples of 5.
--------------------------------------------*/
void xTable() {
    printf("+   ");
    for (int x = 5; x <= 100; x += 5) printf("%6d", x);
    printf("\n");
    for (int y = 5; y <= 100; y += 5) {
        printf("%3d ", y);
        for (int x = 5; x <= 100; x += 5) printf("%6.1f", (pow(x, 4) / pow(y, 4)) + sqrt(y));
        printf("\n");
    }
}

/*------------------------------------------
Function: squeeze
Description: Compresses input by replacing repeating
characters with the character followed by the count.
--------------------------------------------*/
void squeeze() {
    char prev = '\0', curr;
    int count = 0;
    while ((curr = getchar()) != EOF) {
        if (curr == prev) {
            count++;
            if (count == 9) {
                printf("%c%d", prev, count);
                count = 0;
            }
        } else {
            if (count > 0) printf("%c%d", prev, count);
            prev = curr;
            count = 1;
        }
    }
    if (count > 0) printf("%c%d", prev, count);
    printf("\n");
}

/*------------------------------------------
Main Function
--------------------------------------------*/
int main() {
    printf("Choose a program to run:\n1. CardinalSort\n2. CountingCovid\n3. xTable\n4. Squeeze\n");
    int choice;
    scanf("%d", &choice);
    getchar();
    switch (choice) {
        case 1: cardinalSort(); break;
        case 2: countingCovid(); break;
        case 3: xTable(); break;
        case 4: squeeze(); break;
        default: printf("Invalid choice.\n");
    }
    return 0;
}
